"""Reproducible synthetic experiment. Python 3 standard library only."""
from pathlib import Path
import csv, json, random, sqlite3, math, hashlib
ROOT=Path(__file__).resolve().parent
SEED=8080954

def write_csv(name, fields, rows):
    with (ROOT/name).open('w',newline='') as f:
        w=csv.writer(f); w.writerow(fields); w.writerows(rows)

def simulate():
    rng=random.Random(SEED)
    exposures=[];events=[]
    # Synthetic eligible users; independent Bernoulli random assignment at first exposure.
    for i in range(1,10001):
        arm='treatment' if rng.random()<.5 else 'control'
        day=rng.randrange(14)
        exposures.append((i,arm,day))
        # Deliberately invented generating process, not estimated employer parameters.
        started=rng.random()<(.90 if arm=='treatment' else .88)
        completed=started and rng.random()<(.77 if arm=='treatment' else .70)
        error=rng.random()<(.032 if arm=='treatment' else .03)
        if started: events.append((i,'start',day+rng.randrange(2)))
        if completed: events.append((i,'complete',day+2+rng.randrange(5)))
        if error: events.append((i,'error',day+rng.randrange(7)))
    write_csv('exposures.csv',['user_id','arm','exposure_day'],exposures)
    write_csv('events.csv',['user_id','event_name','event_day'],events)

def analyze():
    db=sqlite3.connect(':memory:')
    db.executescript('CREATE TABLE exposures(user_id INTEGER PRIMARY KEY, arm TEXT, exposure_day INTEGER); CREATE TABLE events(user_id INTEGER,event_name TEXT,event_day INTEGER);')
    for name,table in [('exposures.csv','exposures'),('events.csv','events')]:
        with (ROOT/name).open() as f:
            r=csv.reader(f);next(r); db.executemany('INSERT INTO '+table+' VALUES(?,?,?)',r)
    sql=(ROOT/'cohort.sql').read_text()
    rows=[dict(zip(['arm','n','started','completed','errors'],r)) for r in db.execute(sql)]
    arms={r['arm']:r for r in rows};c=arms['control'];t=arms['treatment']
    def difference(key):
        pc=c[key]/c['n'];pt=t[key]/t['n'];d=pt-pc
        se=math.sqrt(pc*(1-pc)/c['n']+pt*(1-pt)/t['n'])
        return {'control_rate':pc,'treatment_rate':pt,'difference_pp':100*d,'ci95_pp':[100*(d-1.96*se),100*(d+1.96*se)]}
    completion=difference('completed');error=difference('errors')
    z=(t['n']-5000)/math.sqrt(10000*.5*.5)
    srm_p=math.erfc(abs(z)/math.sqrt(2))
    # Invented, predeclared decision thresholds in metric-contract.md.
    primary_pass=completion['ci95_pp'][0]>1.0
    guardrail_pass=error['ci95_pp'][1]<1.0
    integrity_pass=srm_p>=.01
    result={'label':'SYNTHETIC DATA - NOT AIRBNB OR EMPLOYER RESULTS','seed':SEED,'users':10000,'arms':rows,'completion':completion,'error_guardrail':error,'assignment_balance_p_approx':srm_p,'thresholds':{'completion_lower_ci_above_pp':1.0,'error_upper_ci_below_pp':1.0,'srm_p_min':.01},'checks':{'primary':primary_pass,'guardrail':guardrail_pass,'assignment':integrity_pass},'decision':'Eligible for a limited monitored rollout in this synthetic scenario' if primary_pass and guardrail_pass and integrity_pass else 'Hold rollout in this synthetic scenario; decision criteria not all met'}
    (ROOT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

def checks(r):
    assert sum(x['n'] for x in r['arms'])==10000
    assert {x['arm'] for x in r['arms']}=={'control','treatment'}
    assert all(0<=x['completed']<=x['started']<=x['n'] and x['errors']<=x['n'] for x in r['arms'])
    # SQL boundary/deduplication and exposure-denominator checks, not just generated happy path.
    d=sqlite3.connect(':memory:');d.executescript('CREATE TABLE exposures(user_id INTEGER,arm TEXT,exposure_day INTEGER);CREATE TABLE events(user_id INTEGER,event_name TEXT,event_day INTEGER);INSERT INTO exposures VALUES(1,"control",10),(2,"control",10);INSERT INTO events VALUES(1,"start",10),(1,"complete",16),(1,"complete",16),(1,"error",17),(2,"complete",9);')
    assert list(d.execute((ROOT/'cohort.sql').read_text()))==[('control',2,1,1,0)]

if __name__=='__main__':
    simulate();r=analyze();checks(r)
    a=(ROOT/'results.json').read_bytes();simulate();r=analyze();checks(r);assert a==(ROOT/'results.json').read_bytes()
    print(json.dumps(r,indent=2));print('PASS: deterministic regeneration, funnel invariants, duplicate and window boundary tests')
