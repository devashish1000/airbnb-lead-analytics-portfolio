-- Intent-to-treat denominator: all exposed eligible users, not only starters.
-- Seven-day window includes days exposure_day through exposure_day + 6.
WITH user_outcomes AS (
 SELECT x.user_id, x.arm,
 MAX(CASE WHEN e.event_name='start' THEN 1 ELSE 0 END) AS started,
 MAX(CASE WHEN e.event_name='complete' THEN 1 ELSE 0 END) AS completed,
 MAX(CASE WHEN e.event_name='error' THEN 1 ELSE 0 END) AS errors
 FROM exposures x LEFT JOIN events e
 ON x.user_id=e.user_id AND e.event_day>=x.exposure_day AND e.event_day<x.exposure_day+7
 GROUP BY x.user_id,x.arm
)
SELECT arm,COUNT(*) AS n,SUM(started),SUM(completed),SUM(errors)
FROM user_outcomes GROUP BY arm ORDER BY arm;
