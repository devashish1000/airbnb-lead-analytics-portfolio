# Reproduce the synthetic product experiment

This is completed analytical work using generated data, not a real company experiment. See metric-contract.md before interpreting results.

Download the complete ZIP, extract it, then run from the extracted folder:

```sh
python3 analyze.py
```

Python 3 standard library only; no network, account or external dependencies. The script deterministically regenerates exposures.csv and events.csv, executes cohort.sql in SQLite, recomputes results.json, and runs boundary/deduplication and reproducibility checks. Existing generated CSV/results files in this sample folder are overwritten.

Files: exposures.csv (one row per randomized user); events.csv (event rows); cohort.sql (user-level window/funnel); analyze.py (generation, estimates, uncertainty and decision); metric-contract.md (assumptions and limits); results.json (computed output).

The reported rollout decision applies only to the invented scenario. An executable notebook is not required to reproduce this script-based analysis. No historical employment claim is validated by this exercise.
