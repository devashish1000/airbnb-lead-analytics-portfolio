# Synthetic onboarding experiment: metric contract

**Independent executed demonstration. All users, events, assignment, effects and thresholds are invented. No Airbnb or employer data; not evidence of a historical work result.**

Question: would a simplified onboarding flow improve completion without unacceptable errors?

- Population: 10,000 synthetic eligible users, each first exposed once. Exposure days span 0-13; all users have seven full days of observable follow-up through day 19. There are no exclusions after assignment.
- Assignment: independent Bernoulli 50/50 control/treatment at user level, PRNG seed 8080954. Assignment happens before event generation. No crossover or interference is simulated.
- Primary outcome: unique users with a completion event within days [exposure, exposure+7), divided by all exposed users in the arm (intention-to-treat). Funnel start uses the same denominator. Duplicate events count once; users with no events remain in denominator.
- Guardrail: unique users with at least one error event in the same window / all exposed users. It is an outcome measured separately, not a post-treatment exclusion.
- Effect: treatment minus control, percentage points. Two-sided 95% normal-approximation confidence interval for difference of independent proportions. Large cell counts make this suitable for the demonstration; no exact or cluster-robust inference is claimed.
- Assignment diagnostic: approximate two-sided binomial-normal balance p-value against 50/50; investigate if below 0.01. This is only a balance check, not proof of instrumentation quality.
- Illustrative decision rules fixed in code before analysis: lower completion-effect CI > +1 percentage point; upper error-effect CI < +1 percentage point; assignment p >= .01. These are invented practical thresholds, not Airbnb standards. All conditions must pass for a limited monitored rollout recommendation.
- No repeated peeking or subgroup search. One primary outcome and one safety gate; the joint gate is conservative. No multiplicity-adjusted familywise interval is claimed.
- Missingness, attrition, bot traffic, delayed events, noncompliance, novelty, clustered assignment, and real-world interference are not modeled. No offline estimate establishes long-term retention or financial value.
- A live rollout would still require instrumentation review, adequate prospective sample sizing, approved harm thresholds and monitoring/rollback ownership. No such real-world checks are claimed completed here.

Generation probabilities are artificial: control/treatment start .88/.90, conditional completion .70/.77, user error .030/.032. They are disclosed to make the demonstration auditable, not to suggest a desired real-world answer.
