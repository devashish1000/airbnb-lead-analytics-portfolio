# Dev Neupane — Strategic Finance & Analytics

Separate local Next.js portfolio for Technology Finance & Planning, built with the refined portfolio system. Historical achievements are user-confirmed, not independently audited. The technology investment decision sample is explicitly hypothetical.

## Preview

Install with pnpm, then `pnpm build` and `PORT=4176 pnpm start`.
Open http://127.0.0.1:4176/airbnb-lead-analytics-portfolio/ .

Both final Airbnb PDFs are in public/ and linked on the page. Historical content is in src/data/content.ts; hypothetical framework is in src/data/casework.ts.

## Status

Local/unpublished. No remote configured. Manual Pages workflow restricted to devashish1000/airbnb-lead-analytics-portfolio; no repository has been created or pushed. Original github.io, PM and logistics packages remain untouched.

Historical Airbnb requisition8758949 returns404 and is absent from the current board, checked September14,2026. The materials target the Technology Finance & Analytics function and do not claim an active vacancy, application or referral.
