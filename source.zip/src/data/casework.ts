// Independent hypothetical framework: no employer data or achieved result.
export type CasePoint = { title: string; detail: string };
export const decisionSample = {
 scenario: "A technology team is considering a tool change while demand and future usage remain uncertain. The finance partner needs to compare credible alternatives and make assumptions visible before recommending a commitment.",
 foundations: [
  {title:"Baseline",detail:"Current cost, service scope, usage, committed obligations and planning horizon. I would record the source, owner and confidence of each input, separating confirmed terms from estimates."},
  {title:"Options",detail:"Retain, optimize, phase an alternative or replace, where technically and contractually feasible. Compare the same required capability and time horizon rather than different service scopes."},
  {title:"Sensitivity",detail:"Demand, adoption, unit price and implementation timing. Show which assumptions change the recommendation and how fixed commitments affect downside exposure."},
  {title:"Decision",detail:"Required capability, total cost, risk, flexibility and confidence in benefits. Separate mandatory requirements from preferences that can be traded off."},
 ],
 drivers: [
  {title:"Price and usage",detail:"Review license pricing, purchase quantities, utilization, infrastructure consumption and renewal terms. Confirm relevant tiers, minimum commitments and limits with the responsible owners."},
  {title:"Transition and operation",detail:"Include relevant implementation, integration, migration, overlap, support and exit costs. Technical partners would validate delivery effort and timing assumptions."},
  {title:"Financial treatment",detail:"Keep cash spending, accounting expense and resource capacity distinct. Staff time saved is not automatically cash savings. Use agreed finance policy for any discounting or capitalization; no rate or treatment is assumed here."},
 ],
 steps: [
  {title:"Build a common baseline",detail:"Reconcile the cost and usage inputs, document scope, and identify commitments that remain under each option. Resolve material inconsistencies before comparing totals."},
  {title:"Test the recommendation",detail:"Compare base and downside cases using consistent assumptions. Identify the adoption, cost or timing conditions under which the preferred option changes, and make those conditions explicit."},
  {title:"Choose the next commitment",detail:"Recommend an option only when the evidence supports it. Otherwise propose a bounded validation step or deferral, with an owner, decision date and criteria for proceeding."},
 ],
 checkpoints: [
  {title:"Before approval",detail:"Document financial and technical review, unresolved assumptions, the decision owner and required sign-offs. A comparison is not authorization to spend."},
  {title:"After a decision",detail:"Track actual adoption, cost and service outcomes against the agreed assumptions. Define review triggers and corrective actions; distinguish forecast benefit from an evidenced realized result."},
 ],
};
