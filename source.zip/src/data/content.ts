// Historical achievements are user-confirmed. Synthetic demonstrations are labeled separately.
export const recruiterIntro = "I lead measurement planning and use A/B experiments, causal analysis, and SQL and Python models to guide product and operating decisions. At LinkedIn, experiments informed a five-site rollout as handling time fell 15% while decision quality was maintained.";
export const stories = [
  {
    "company": "LinkedIn",
    "title": "Faster workflows, with quality protected",
    "summary": "A/B experiments informed a five-site rollout while decision quality was maintained.",
    "metric": "15%",
    "metricLabel": "lower handling time",
    "disclosure": "Read the experimentation brief",
    "scope": "A/B workflow experiments with reviewer-level random assignment, prespecified handling-time and adjudicated-quality measures, and a fixed analysis window. I evaluated uncertainty before recommending rollout. The matched-cohort analysis below is separate related work.",
    "contribution": "Used SQL and Python matched-cohort analysis to evaluate policy and capacity changes; identified an intervention that reduced repeat errors 18%, directing investment toward the highest-impact workflows.",
    "outcome": "Designed A/B experiments with hypotheses, success metrics, and guardrails; handling time fell 15% while decision quality was maintained, informing rollout across five sites."
  },
  {
    "company": "Southwest Airlines",
    "title": "Testing an operational improvement",
    "summary": "A controlled scheduling experiment informed a phased rollout without increasing overtime.",
    "metric": "12%",
    "metricLabel": "lower turnaround time versus comparison locations",
    "disclosure": "Read the operational experiment brief",
    "scope": "Primary work: controlled scheduling experiment across participating and comparison locations. The difference-in-differences analysis below is related work; its productivity measure is separate from turnaround time.",
    "contribution": "Used difference-in-differences with intervention and comparison locations, checked pre-intervention trends, and assessed sensitivity to seasonality and demand changes. The estimated 8% productivity improvement informed resource allocation; productivity is a separate measure from turnaround time.",
    "outcome": "The scheduling intervention reduced turnaround time 12% versus comparison locations without increasing overtime, supporting a phased rollout."
  },
  {
    "company": "Allen & Overy",
    "title": "Comparing implementation alternatives",
    "summary": "An evaluation of adoption, processing time and service quality informed implementation selection.",
    "metric": "25%",
    "metricLabel": "lower workflow processing time",
    "disclosure": "Read the comparative evaluation brief",
    "scope": "Primary work: comparison of technology and process alternatives. The vendor-performance model below is related work; its resolution-time measure is separate from workflow processing time.",
    "contribution": "Modeled vendor performance accounting for workload differences; identified two drivers of delayed resolution and guided corrective actions that reduced median resolution time from eight to five business days.",
    "outcome": "Identified a workflow with 25% lower processing time without degrading service quality, informing implementation selection."
  }
];
export const experience = [
  {
    "company": "Bellevue University",
    "role": "Software Engineer",
    "dates": "Jul 2026 - Present",
    "achievement": "Designed workflow A/B tests that informed rollout as task completion increased from 78% to 86% over six weeks.",
    "detail": "Designed and analyzed A/B tests for application workflows with success metrics and guardrails; task completion increased from 78% to 86% over six weeks, informing rollout of a redesigned workflow. Used regression controlling for user mix and usage volume to evaluate workflow changes; identified a 20% reduction in processing time and guided prioritization of two release improvements. Automated validation and reconciliation across five data interfaces, reducing manual verification 40% and saving ten staff hours weekly."
  },
  {
    "company": "Southwest Airlines",
    "role": "Senior Performance Analyst, Corporate Analytics",
    "dates": "Apr 2023 - May 2024",
    "achievement": "Designed a controlled scheduling experiment that supported a phased rollout with 12% lower turnaround time versus comparison locations.",
    "detail": "Designed a controlled experiment that identified a scheduling intervention reducing turnaround time 12% versus comparison locations without increasing overtime, supporting a phased rollout. Used difference-in-differences to separate initiative effects from seasonality and demand changes; quantified an 8% productivity improvement and informed resource allocation across participating locations. Built Power BI and Tableau dashboards covering 15+ operational KPIs, trends, and variance drivers; reduced reporting cycle time 60% and recommended corrective priorities in weekly operational exception reviews. For the difference-in-differences analysis, checked pre-intervention trends and sensitivity to seasonality and demand changes before using the estimate to inform resource allocation."
  },
  {
    "company": "LinkedIn",
    "role": "Senior Business Analyst, Planning & Optimization",
    "dates": "Nov 2020 - Mar 2023",
    "achievement": "Designed A/B experiments that informed a five-site rollout as handling time fell 15% while decision quality was maintained.",
    "detail": "Designed A/B experiments with hypotheses, success metrics, and guardrails; handling time fell 15% while decision quality was maintained, informing rollout across five sites. Used SQL and Python matched-cohort analysis to evaluate policy and capacity changes; identified an intervention that reduced repeat errors 18%, directing investment toward the highest-impact workflows. Built SQL and Python forecasts across 120+ planning streams for an $800M+ technology organization, achieving 94% forecast accuracy; identified capacity constraints eight weeks ahead to inform resource plans. Used reviewer-level random assignment, prespecified handling-time and adjudicated-quality measures, and a fixed analysis window; evaluated uncertainty before recommending rollout. Separately, owned weekly updates and decision briefs for Operations and Policy leadership, synthesizing quality trends, delivery risks, and unresolved dependencies into recommendations on priorities, staffing, and release readiness."
  },
  {
    "company": "Allen & Overy",
    "role": "Business Analyst, Finance & Business Management",
    "dates": "Jan 2020 - Nov 2020",
    "achievement": "Compared implementation alternatives, identifying a workflow with 25% lower processing time without degrading service quality.",
    "detail": "Compared technology and process alternatives on adoption, processing time, and service quality; identified a workflow with 25% lower processing time without degrading service quality, informing implementation selection. Modeled vendor performance accounting for workload differences; identified two drivers of delayed resolution and guided corrective actions that reduced median resolution time from eight to five business days."
  },
  {
    "company": "NYC Department of Education",
    "role": "Finance & Budget Analyst, Business Management",
    "dates": "Aug 2019 - Dec 2019",
    "achievement": "Designed reporting pilots across 20 sites; observed a 25% shorter review cycle and informed adoption of standardized checks.",
    "detail": "Designed reporting and review-process pilots measuring turnaround time and data quality; observed a 25% shorter review cycle across 20 pilot sites, informing adoption of standardized submission checks. Applied multivariable regression accounting for site characteristics and submission volume; identified validation gaps associated with repeat errors and guided targeted support for sites with high error rates."
  }
];
export const headwell = {
  "title": "Co-Founder, Product & Analytics (Project)",
  "dates": "Dec 2025 - Present",
  "scope": "Designed A/B tests across product journeys with primary metrics and guardrails; onboarding completion increased from 62% to 71% over four weeks, informing release of a simplified flow. Led measurement planning with product and engineering partners, clarified the decision and success criteria, and recommended changes to test or release after explaining the evidence and tradeoffs.",
  "quality": "Defined ten product and data-quality KPIs, achieving 95% data completeness; classified 500 feedback items using AI with human validation, shortening the feedback-to-decision cycle from seven to three days. Defined eligible-user cohorts and event definitions, built reusable SQL transformations and Python validation checks, and documented outputs for product decisions.",
  "feedback": "Combined behavioral analysis, statistical modeling, and user feedback to identify a first-week engagement bottleneck; informed a feature change that increased seven-day retention by five percentage points.",
  "experimentation": "Designed A/B tests across product journeys with primary metrics and guardrails; onboarding completion increased from 62% to 71% over four weeks, informing release of a simplified flow."
};
