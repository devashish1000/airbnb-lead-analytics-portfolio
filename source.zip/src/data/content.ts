// Historical work and independently executed synthetic analysis remain distinct.
export const recruiterIntro = "I connect experimental design, causal analysis, and SQL/Python measurement to product decisions. My work spans a five-site workflow rollout at LinkedIn and hands-on measurement planning with product and engineering partners on HeadWell.";
export const stories = [
  {
    "company": "LinkedIn",
    "title": "Faster workflows, with quality protected",
    "summary": "Evaluated the speed and quality tradeoff before recommending a five-site workflow rollout.",
    "metric": "15%",
    "metricLabel": "lower handling time",
    "disclosure": "Read the experimentation brief",
    "contribution": "In a separate SQL and Python matched-cohort analysis of policy and capacity changes, identified an intervention that reduced repeat errors 18%, directing investment toward the highest-impact workflows.",
    "outcome": "Designed A/B experiments with hypotheses, success metrics, and guardrails; handling time fell 15% while decision quality was maintained, informing rollout across five sites.",
    "decision": "Whether to roll out workflow changes that improve handling time while protecting decision quality.",
    "method": "Reviewer-level random assignment, prespecified handling-time and adjudicated-quality measures, and a fixed analysis window. I evaluated uncertainty before recommending rollout."
  },
  {
    "company": "Southwest Airlines",
    "title": "Testing an operational improvement",
    "summary": "Compared scheduling outcomes and overtime to inform a phased rollout.",
    "metric": "12%",
    "metricLabel": "lower turnaround time versus comparison locations",
    "disclosure": "Read the operational experiment brief",
    "contribution": "In a separate difference-in-differences analysis, checked pre-intervention trends, event-study diagnostics, placebo tests, alternative comparison groups, and sensitivity to seasonality and demand. The estimated 8% productivity improvement informed resource allocation. This productivity measure differs from the scheduling study’s turnaround-time measure.",
    "outcome": "The scheduling intervention reduced turnaround time 12% versus comparison locations without increasing overtime, supporting a phased rollout.",
    "decision": "Whether a scheduling change merited a phased rollout without increasing overtime.",
    "method": "A controlled scheduling experiment compared turnaround time with comparison locations and tracked overtime."
  },
  {
    "company": "Allen & Overy",
    "title": "Comparing implementation alternatives",
    "summary": "Compared adoption, processing time, and service quality to guide implementation selection.",
    "metric": "25%",
    "metricLabel": "lower workflow processing time",
    "disclosure": "Read the comparative evaluation brief",
    "contribution": "In a separate vendor-performance model, accounted for workload differences and identified two delay drivers. Corrective actions reduced median resolution time from eight to five business days.",
    "outcome": "Identified a workflow with 25% lower processing time without degrading service quality, informing implementation selection.",
    "decision": "Which technology or process alternative to implement while maintaining service quality.",
    "method": "Compared alternatives on adoption, processing time, and service quality."
  }
];
export const experience = [
  {
    "company": "Bellevue University",
    "role": "Software Engineer",
    "dates": "Jul 2026 - Present",
    "achievement": "Designed workflow A/B tests that informed rollout as task completion increased from 78% to 86% over six weeks.",
    "detail": "Designed workflow A/B tests with success metrics and guardrails; completion rose from 78% to 86% over six weeks, informing rollout of the redesigned workflow. Evaluated workflow changes with regression controlling for user mix and usage volume; identified a 20% processing-time reduction and guided prioritization of two release improvements. Automated validation and reconciliation across five data interfaces, reducing manual verification 40% and saving ten staff hours weekly."
  },
  {
    "company": "Southwest Airlines",
    "role": "Senior Performance Analyst, Corporate Analytics",
    "dates": "Apr 2023 - May 2024",
    "achievement": "Designed a controlled scheduling experiment that supported a phased rollout with 12% lower turnaround time versus comparison locations.",
    "detail": "Designed a controlled scheduling experiment; turnaround time fell 12% versus comparison locations without increasing overtime, supporting a phased rollout. Estimated an 8% productivity improvement using difference-in-differences; assessed pre-intervention trends, event-study diagnostics, placebo tests, alternative comparison groups, and sensitivity to seasonality and demand before informing resource allocation. Built Power BI and Tableau dashboards for 15+ operational KPIs, trends, and variance drivers; cut reporting cycle time 60% and recommended corrective priorities in weekly exception reviews."
  },
  {
    "company": "LinkedIn",
    "role": "Senior Business Analyst, Planning & Optimization",
    "dates": "Nov 2020 - Mar 2023",
    "achievement": "Designed A/B experiments that informed a five-site rollout as handling time fell 15% while decision quality was maintained.",
    "detail": "Designed A/B experiments with reviewer-level random assignment, prespecified handling-time and adjudicated-quality measures, and a fixed analysis window. Evaluated uncertainty before recommending a five-site rollout; handling time fell 15% with quality maintained. Evaluated policy and capacity changes using SQL and Python matched-cohort analysis; identified an intervention that reduced repeat errors 18% and directed investment toward the highest-impact workflows. Evaluated and applied pre-experiment variance reduction, power analysis, and valid sequential monitoring to improve experiment precision and inform rollout decisions; tested emerging methods against existing approaches and documented their usefulness. Owned weekly decision briefs for Operations and Policy leadership; translated quality trends, delivery risks, and dependencies into recommendations on staffing, priorities, and release readiness. Separately, built SQL and Python forecasts across 120+ planning streams for an $800M+ technology organization, achieving 94% forecast accuracy and identifying capacity constraints eight weeks ahead to inform resource plans."
  },
  {
    "company": "Allen & Overy",
    "role": "Business Analyst, Finance & Business Management",
    "dates": "Jan 2020 - Nov 2020",
    "achievement": "Compared implementation alternatives, identifying a workflow with 25% lower processing time without degrading service quality.",
    "detail": "Compared technology and process alternatives on adoption, processing time, and service quality; identified a workflow with 25% lower processing time and maintained quality to inform implementation selection. Modeled vendor performance while accounting for workload differences; identified two delay drivers and guided corrective actions that cut median resolution time from eight to five business days."
  },
  {
    "company": "NYC Department of Education",
    "role": "Finance & Budget Analyst, Business Management",
    "dates": "Aug 2019 - Dec 2019",
    "achievement": "Designed reporting pilots across 20 sites; observed a 25% shorter review cycle and informed adoption of standardized checks.",
    "detail": "Designed reporting and review-process pilots across 20 sites, measuring turnaround and data quality; observed a 25% shorter review cycle and informed adoption of standardized submission checks. Applied multivariable regression accounting for site characteristics and submission volume; identified validation gaps associated with repeat errors and guided targeted site support."
  }
];
export const headwell = {
  "title": "Co-Founder, Product & Analytics (Project)",
  "dates": "Dec 2025 - Present",
  "scope": "Led measurement planning with product and engineering partners, defining decisions and success criteria and recommending test or release choices. Onboarding A/B tests informed a simpler flow as completion rose from 62% to 71% over four weeks.",
  "quality": "Defined cohorts and events for ten KPIs; built reusable SQL transformations and Python validation with documented outputs, achieving 95% data completeness. Evaluated AI classification of 500 feedback items using benchmark cases, structured error categories, human review, and a manual baseline; cut feedback-to-decision time from seven to three days.",
  "feedback": "Combined behavioral analysis, statistical modeling, and user feedback to identify a first-week engagement bottleneck; informed a feature change that increased seven-day retention by five percentage points.",
  "experimentation": "Designed A/B tests across product journeys with primary metrics and guardrails; onboarding completion increased from 62% to 71% over four weeks, informing release of a simplified flow."
};
