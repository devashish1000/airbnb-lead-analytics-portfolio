import Image from "next/image";
import { ArrowDown, ArrowRight, ArrowUpRight, Plus } from "@phosphor-icons/react/dist/ssr";
import { Header } from "@/components/Header";
import { DecisionSample } from "@/components/Casework";
import { stories, experience, headwell, recruiterIntro } from "@/data/content";

const base = "/airbnb-lead-analytics-portfolio";
const resume = `${base}/Dev_Neupane_Airbnb_Lead_Analytics_Resume.pdf`;

export default function Home() {
  return <><Header /><main id="main" tabIndex={-1}>
    <section className="hero shell" aria-labelledby="hero-title">
      <div className="hero-copy">
        <p className="hero-role">Product analytics · Experimentation &amp; measurement</p>
        <h1 id="hero-title">Better questions.<br /><em>Tested decisions.</em><br />Measurable impact.</h1>
        <p className="hero-intro">{recruiterIntro}</p>
        <div className="hero-actions"><a className="button" href="#work">Explore selected work <ArrowRight size={22} aria-hidden="true" /></a><a className="text-link" href={resume} download>Download résumé <ArrowDown size={19} aria-hidden="true" /></a><a className="hero-profile" href="https://linkedin.com/in/devashishn" target="_blank" rel="noopener noreferrer">LinkedIn <ArrowUpRight size={16} aria-hidden="true" /></a></div>
      </div>
      <figure className="portrait"><Image src={`${base}/dev-neupane-headshot.webp`} width={640} height={800} alt="Dev Neupane" priority sizes="(max-width: 700px) 48vw, 28vw" /><figcaption>Experimentation · Forecasting · Analytics</figcaption></figure>
    </section>

    <section className="impact shell" aria-labelledby="impact-title">
      <div className="section-label-row"><h2 id="impact-title" className="small-label">Selected impact</h2><span>Experimentation · Operations · Product measurement</span></div>
      <div className="impact-grid">
        <div><strong>15%</strong><p>Lower handling time · LinkedIn</p></div>
        <div><strong>12%</strong><p>Lower turnaround time vs. comparison locations · Southwest Airlines</p></div>
        <div><strong>+9 <span>pp</span></strong><p>Onboarding completion · HeadWell project</p></div>
      </div>
    </section>

    <section id="work" className="work shell" tabIndex={-1} aria-labelledby="work-title">
      <div className="section-heading"><h2 id="work-title">Selected work.</h2><p>Experiments, forecasts, and business decisions.</p></div>
      <div className="work-list">{stories.map((story, i) => <article className="story" key={story.title}>
        <div className="story-source"><span>{String(i+1).padStart(2,"0")}</span><p>{story.company}</p></div>
        <div className="story-content"><h3>{story.title}.</h3><p>{story.summary}</p></div>
        <div className="story-metric"><strong className={i === 2 ? "wide-metric" : undefined}>{story.metric}</strong><p>{story.metricLabel}</p></div>
        <details className="story-details"><summary>{story.disclosure} <Plus size={17} aria-hidden="true" /></summary>{<div className="expanded-story"><dl><div><dt>Scope</dt><dd>{story.scope}</dd></div><div><dt>Related analytical work</dt><dd>{story.contribution}</dd></div><div><dt>Outcome</dt><dd>{story.outcome}</dd></div></dl></div>}</details>
      </article>)}</div>
      <div className="program-context"><h3>The measurement behind the decisions.</h3><div><article><h4>Experimentation and causal analysis</h4><p>At LinkedIn, I designed A/B experiments with hypotheses, success metrics, and guardrails. At Southwest Airlines, I applied causal analysis to distinguish initiative impact from seasonality and demand changes.</p></article><article><h4>Reliable inputs</h4><p>At Bellevue University, I automated validation and reconciliation checks across five data interfaces. This reduced manual verification 40% and saved ten staff hours weekly.</p></article></div></div>
    </section>

    <section id="project" className="project" aria-labelledby="project-title"><div className="shell project-grid">
      <div><p className="small-label">Project / HeadWell</p><h2 id="project-title">From experiments<br />to product decisions.</h2><p className="project-role">{headwell.title} · {headwell.dates}</p><p className="project-intro">A/B tests informed a simplified onboarding flow as completion increased from 62% to 71% over four weeks.</p><p className="project-ai">Human-validated AI classification of 500 feedback items shortened the feedback-to-decision cycle from seven to three days.</p>
        <details className="story-details project-details"><summary>Read the HeadWell analytics summary <Plus size={18} aria-hidden="true" /></summary><div className="expanded-story"><dl><div><dt>Onboarding experiment</dt><dd>{headwell.scope}</dd></div><div><dt>Data quality</dt><dd>{headwell.quality}</dd></div><div><dt>Engagement and retention</dt><dd>{headwell.feedback}</dd></div></dl><p className="project-note">Project · Initial release on TestFlight</p></div></details>
      </div>
      <div className="project-metrics"><div><strong>62% → 71%</strong><p>Onboarding completion over four weeks</p></div><div><strong>+5 <span>pp</span></strong><p>Seven-day retention following a feature change</p></div></div>
    </div></section>

    <DecisionSample />

    <section id="experience" className="experience shell" tabIndex={-1} aria-labelledby="experience-title">
      <div className="experience-heading"><h2 id="experience-title">Experience.</h2><p>Experimentation, causal analysis, and cross-functional decision support.</p><a className="experience-work-link" href="#work">Explore selected work <ArrowUpRight size={17} aria-hidden="true" /></a><a className="text-link" href={resume} download>Full résumé <ArrowDown size={18} aria-hidden="true" /></a></div>
      <div className="experience-list">{experience.map(item => <article key={item.company}><div className="experience-top"><h3>{item.company}</h3><p className="dates">{item.dates}</p></div><p className="role">{item.role}</p><p className="achievement">{item.achievement}</p><details className="experience-details"><summary>More about {item.company}</summary><p>{item.detail}</p></details></article>)}
        <div className="education"><h3>University of Nebraska Omaha</h3><p>MBA, Supply Chain &amp; Logistics · 2025<br />B.S., Management Information Systems · 2019</p><span>Highest Distinction · Both degrees</span></div>
      </div>
    </section>

    <footer id="contact" className="contact shell" tabIndex={-1}><div className="contact-main"><h2>Let’s discuss<br />product analytics.</h2><div className="contact-details"><p>Product analytics · Experimentation &amp; measurement<br />Open to relocation</p><a className="email" href="mailto:devashish1000@gmail.com">devashish1000@gmail.com <ArrowUpRight size={23} aria-hidden="true" /></a><div className="contact-links"><a href="https://linkedin.com/in/devashishn" target="_blank" rel="noopener noreferrer">LinkedIn <ArrowUpRight size={15} aria-hidden="true" /></a><a href="https://github.com/devashish1000" target="_blank" rel="noopener noreferrer">GitHub <ArrowUpRight size={15} aria-hidden="true" /></a><a href={resume} download>Résumé <ArrowDown size={15} aria-hidden="true" /></a><a href={`${base}/Dev_Neupane_Airbnb_Lead_Analytics_Cover_Letter.pdf`} download>Cover letter <ArrowDown size={15} aria-hidden="true" /></a></div></div></div><div className="footer-bottom"><span>Dev Neupane © 2026</span><a href="#top">Back to top <ArrowUpRight size={16} aria-hidden="true" /></a></div></footer>
  </main></>;
}
