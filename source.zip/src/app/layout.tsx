import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  icons: { icon: "/airbnb-lead-analytics-portfolio/favicon.svg" },
  title: "Dev Neupane — Product Analytics & Experimentation",
  description: "Selected work in A/B testing, causal analysis, SQL and Python modeling, forecasting, and product measurement.",
  metadataBase: new URL("https://devashish1000.github.io/airbnb-lead-analytics-portfolio/"),
  alternates: { canonical: "https://devashish1000.github.io/airbnb-lead-analytics-portfolio/" },
  openGraph: {
    title: "Dev Neupane — Product Analytics & Experimentation",
    description: "Better questions. Tested decisions. Measurable impact.",
    type: "website",
    url: "https://devashish1000.github.io/airbnb-lead-analytics-portfolio/",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><a className="skip-link" href="#main">Skip to content</a>{children}</body></html>;
}
