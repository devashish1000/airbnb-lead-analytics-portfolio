import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "export",
  basePath: "/airbnb-lead-analytics-portfolio",
  trailingSlash: true,
  images: { unoptimized: true },
};

export default nextConfig;
